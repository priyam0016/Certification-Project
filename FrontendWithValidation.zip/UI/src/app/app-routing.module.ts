
import { ProductAddComponent } from './product-add/product-add.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ProductsComponent } from './products/products.component';
import { HomeComponent } from './home/home.component';
import { Routes } from "@angular/router";
import { ProductDeleteComponent } from './product-delete/product-delete.component';
import { ProductEditComponent } from './product-edit/product-edit.component';

export const applicationRoutes: Routes = [
    // { path: '', component: HomeComponent },
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'products', component: ProductsComponent },
    { path: 'product-detail/:_id', component: ProductDetailComponent },
    { path: 'product-add', component: ProductAddComponent },
    {path: 'product-delete/:_id', component: ProductDeleteComponent},
    {path: 'product-edit/:_id', component: ProductEditComponent},
]