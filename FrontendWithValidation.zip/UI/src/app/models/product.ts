export class Product {
    name: string = "";
    department: string ="";
    price: number;
    discountPrice: number;
    image: string ="";
    description: string ="";
}