export class Product {
    name: string = "";
    department: string ="";
    price: number = 0;
    discountPrice: string ="";
    image: string ="";
    description: string ="";
}