import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  productList: any;
  isAdmin: Boolean;

  constructor(private _httpClient: HttpClient) {
    this.isAdmin = false;
  }


  ngOnInit(): void {

      this._httpClient.get('http://localhost:8080/products')
      .subscribe(result => {
        this.productList = result["productList"];
      }, error => {
        console.log((error)); 
      })
  }
}
